/**
*  Author:  Simon Berhe                                                                                                     
*  Date:    March 11th                                                                                                      
*  Description: This Pacman game requires you to collect all 155 dots in less then 90 seconds to win. 
                There will be if statements, data types, and although it is no heacy object oriented, 
                there are still some concepts used in the code. The main focus in this code is 2 dimensional arrays.                                        
*/
import javax.swing.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.BasicStroke;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.Image;
import java.util.Random;
import java.io.*;   
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import javax.swing.border.Border;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;


public class SimonPak
{
   static final long serialVersionUID = 2;
   
   public static void main(String args[]) throws Exception 
   { 
      PacManBoard gameBoard = new PacManBoard();
      gameBoard.setLocationRelativeTo(null);
      gameBoard.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      gameBoard.init();
   }
}


class PacManBoard extends JFrame implements KeyListener
{
   static final long serialVersionUID = 2;
   BufferedImage buffer;
   char[][] board = {{'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'},
                  {'X', 'P', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'X'},
                  {'X', '*', 'X', '*', 'X', 'X', '*', 'X', 'X', 'X', 'X', 'X', 'X', '*', 'X', 'X', '*', 'X', '+', 'X'},
                  {'X', '*', 'X', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'X', '*', 'X'},
                  {'X', '*', 'X', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'X', '*', 'X'},
                  {'X', '*', 'X', 'X', 'X', 'X', '*', 'X', 'X', '-', '-', 'X', 'X', '*', 'X', 'X', 'X', 'X', '*', 'X'},
                  {'X', '*', '*', '*', '*', '*', '*', 'X', '1', '2', '3', '4', 'X', '*', '*', '*', '*', '*', '*', 'X'},
                  {'X', '*', 'X', 'X', 'X', 'X', '*', 'X', 'X', 'X', 'X', 'X', 'X', '*', 'X', 'X', 'X', 'X', '*', 'X'},
                  {'X', '*', 'X', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'X', '*', 'X'},
                  {'X', '*', 'X', '*', '*', '*', '*', '*', 'X', 'X', 'X', 'X', '*', '*', '*', '*', '*', 'X', '*', 'X'},
                  {'X', '*', 'X', '*', '*', '*', '*', '*', 'X', '*', '*', 'X', '*', '*', '*', '*', '*', 'X', '*', 'X'},
                  {'X', '*', 'X', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'X', '*', 'X'},
                  {'X', '*', 'X', '*', 'X', 'X', '*', 'X', 'X', 'X', 'X', 'X', 'X', '*', 'X', 'X', '*', 'X', '*', 'X'},
                  {'X', '+', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'X'},
                  {'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'}};
    
   char pacmanShape = 'R';
   char direction = 'R';
   int pacmanR = 1;
   int pacmanC = 1;
   int points = 0;
   char power;
   long timer = 0;
   long end = 90;
   long startTime = 5000;
   long start = System.currentTimeMillis();
       
   final int WIDTH = board[0].length*30, HEIGHT = board.length*30;
   JPanel boardPanel;
   
   
   public PacManBoard()
   {
      super ("PACMAN");
      
      buffer = new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);
      
      boardPanel = new JPanel();
      boardPanel.setDoubleBuffered(true);
      boardPanel.setPreferredSize(new Dimension(WIDTH,HEIGHT));
      boardPanel.setMinimumSize(new Dimension(WIDTH,HEIGHT));
      
      JPanel pane = (JPanel) getContentPane();
      addKeyListener(this);
      pane.add(boardPanel);
      pane.setDoubleBuffered(true);
      setSize(WIDTH+40, HEIGHT+40);
      pack();
      setLocationRelativeTo(null);
      setVisible(true);
   }
   
   
   public void keyTyped(KeyEvent e)
   {
   
   
   }
   
   
   public void keyPressed(KeyEvent e)
   {
      int key = e.getKeyCode();
      if (key == KeyEvent.VK_LEFT)
         direction = 'L';
      if (key == KeyEvent.VK_RIGHT)
         direction = 'R';
      if (key == KeyEvent.VK_UP)
         direction = 'U';
      if (key == KeyEvent.VK_DOWN)
         direction = 'D';   
   }
   
   
   public void keyReleased(KeyEvent e)
   {
   
   
   
   } 
          
       
   public void drawBoard()
   {
      Graphics2D b = buffer.createGraphics();
      BufferedImage boardImage = null;
      b.setColor(Color.black);
      b.fillRect(0,25, WIDTH, HEIGHT);
      for (int row = 0; row<board.length; row++){
         for (int column = 0; column < board[row].length; column++){
            if (board[row][column] == 'X') 
            {
               b.setColor(new Color(28,24,224));
               b.fillRect((column) * 30, (row) * 30, 30, 30);
            }
            else if (board[row][column] == '*'){ 
               b.setColor(new Color(245,243,184));
               b.fillOval((column) * 30 +9, (row) * 30 +9, 10,10);
            }
            else if (board[row][column] == '-')
            { 
               b.setColor(new Color(52,174,235));
               b.setStroke(new BasicStroke(6));
               b.drawLine(column * 30 +3, row * 30 + 12, column * 30 + 27, row * 30 + 12);
            }
            else if (board[row][column] >= '1' && board[row][column] <= '6')
            {
            
               addGhost(b,board[row][column], column *30, row*30);
                     
            }
            else if (board[row][column] == '+')
            {
            
               addPower(b,board[row][column], column*30, row*30);
            }   
            else if (board[row][column] == 'P') {
               pacmanR = row; pacmanC = column;
               if (System.currentTimeMillis() - startTime <= 5000)
                  b.setColor(Color.green);
               else            
                  b.setColor(Color.yellow);
               if (pacmanShape == 'O')
                  b.fillArc((column) * 30 + 3, (row) * 30 + 3, 24, 24, 0, 365);
               else if (pacmanShape == 'R')
                  b.fillArc((column) * 30 + 3, (row) * 30 + 3, 24, 24, 45, 270);
               else if (pacmanShape == 'L')
                  b.fillArc((column) * 30 + 3, (row) * 30 + 3, 24, 24, 180+45, 270);
               else if (pacmanShape == 'U')
                  b.fillArc((column) * 30 + 3, (row) * 30 + 3, 24, 24, 90+45, 270);
               else if (pacmanShape == 'D')
                  b.fillArc((column) * 30 + 3, (row) * 30 + 3, 24, 24, 270+45, 270);
            }
         
         }
                        
      }
      b.setColor(new Color(255, 255, 255));
      b.setFont(new Font("Serif", Font.PLAIN, 23));
      b.drawString("Score: " + points, 10, HEIGHT - 10);
      
      timer = (System.currentTimeMillis() - start)/1000;
      
      b.setColor(new Color(255, 255, 255));
      b.setFont(new Font("Serif", Font.PLAIN, 20));
      b.drawString("Timer: " + timer + " (90 Seconds max)" , 350, HEIGHT - 10);
              
      b.drawImage(boardImage,0,15,this);
      b.dispose();
      drawScreen();
   }


   public void drawScreen()
   {
      Graphics2D g = (Graphics2D)this.getGraphics();
      g.drawImage(buffer,6,30,this);
      Toolkit.getDefaultToolkit().sync();
      g.dispose();
   } 
   
   
   public void init()
   {
      
      play("Pac-man theme remix - By Arsenic1987.wav");
      start = System.currentTimeMillis();
      Graphics2D b = buffer.createGraphics();
      drawBoard();
      b.dispose();
      drawScreen();
      gameLoop();
   }
   
   
   public void play(String song)
   {
      try{
         AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(this.getClass().getResource(song));
         Clip myClip = AudioSystem.getClip();
         myClip.open(audioInputStream);
         myClip.start();
      }
      catch(Exception ex) {
         System.out.println("Caught in method: "+ex);
      }
   }
   

   public void gameLoop()
   {
      while(true)
      {
         try
         {
            move();  
            detectWinner();
            detectLoser();     
            drawBoard(); 
                
            if (System.currentTimeMillis() - startTime <= 5000)
               Thread.sleep(150);
            else
               Thread.sleep(500);   
         }
         catch(Exception e)
         {
            e.printStackTrace();
         }
      }
   
   } 
   
   
   public void addGhost(Graphics2D b, char ghost, int x, int y)
   {
      BufferedImage img = null;      
      Image newImage = null;
      try
      {
         if (ghost == '1')
            img = ImageIO.read( new File("Black2.png"));
         else if (ghost == '2')
            img = ImageIO.read( new File("Black2.png"));
         else if (ghost == '3')
            img = ImageIO.read( new File("Black2.png"));
         else if (ghost == '4')
            img = ImageIO.read( new File("Black2.png"));   
         
         
         
         newImage = img.getScaledInstance(24, 30, Image.SCALE_DEFAULT);
         b.drawImage(newImage, x+3, y, this);
         
             
      }
      
      catch(Exception e)
      {
         e.printStackTrace();
         System.out.println("Runtime error caught in addGhost: picture for ghost \""+ghost+"\" not found or read properly.");
         System.exit(0);
      }
      
   }
 
  
   public void addPower(Graphics2D b, char power, int x, int y)
   {
      BufferedImage img = null;
      Image newImage = null;
      try
      {
         if (power == '+')
            img = ImageIO.read( new File("Strawberry.png"));
            
               
         newImage = img.getScaledInstance(24, 30, Image.SCALE_DEFAULT);
         b.drawImage(newImage, x+3, y, this);
      }
      
      catch(Exception e)
      {
         e.printStackTrace();
         System.out.println("Runtime error caught in addPower: picture for powerup \""+power+"\" not found or read properly.");
         System.exit(0);
      }    
   
   }
      
      
   public void move()
   {
      int row = pacmanR;
      int column = pacmanC;
      if (pacmanShape == 'O')
         pacmanShape = direction;
      else
         pacmanShape = 'O';
      
      if (direction == 'R'){
       
         column = pacmanC+1;  
      }
      
      if (direction == 'U')
         row = pacmanR-1;
      
      if (direction == 'L')
         column = pacmanC-1;
         
      if (direction == 'D')
         row = pacmanR+1;
      
      
      {
         if(board[row][column] != 'X' && board[row][column] != '-')
         {
            if(board[row][column] == '*')
               points++;  
            
            if(board[row][column] == '+')
               startTime = System.currentTimeMillis();   
                         
            board[pacmanR][pacmanC] = ' ';
            board[row][column] = 'P';   
         }      
         
      }
       
   }
   
   
   public void resetBoard()
   {
      board = new char[][]{{'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'},
                  {'X', 'P', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'X'},
                  {'X', '*', 'X', '*', 'X', 'X', '*', 'X', 'X', 'X', 'X', 'X', 'X', '*', 'X', 'X', '*', 'X', '+', 'X'},
                  {'X', '*', 'X', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'X', '*', 'X'},
                  {'X', '*', 'X', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'X', '*', 'X'},
                  {'X', '*', 'X', 'X', 'X', 'X', '*', 'X', 'X', '-', '-', 'X', 'X', '*', 'X', 'X', 'X', 'X', '*', 'X'},
                  {'X', '*', '*', '*', '*', '*', '*', 'X', '1', '2', '3', '4', 'X', '*', '*', '*', '*', '*', '*', 'X'},
                  {'X', '*', 'X', 'X', 'X', 'X', '*', 'X', 'X', 'X', 'X', 'X', 'X', '*', 'X', 'X', 'X', 'X', '*', 'X'},
                  {'X', '*', 'X', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'X', '*', 'X'},
                  {'X', '*', 'X', '*', '*', '*', '*', '*', 'X', 'X', 'X', 'X', '*', '*', '*', '*', '*', 'X', '*', 'X'},
                  {'X', '*', 'X', '*', '*', '*', '*', '*', 'X', '*', '*', 'X', '*', '*', '*', '*', '*', 'X', '*', 'X'},
                  {'X', '*', 'X', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'X', '*', 'X'},
                  {'X', '*', 'X', '*', 'X', 'X', '*', 'X', 'X', 'X', 'X', 'X', 'X', '*', 'X', 'X', '*', 'X', '*', 'X'},
                  {'X', '+', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'X'},
                  {'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'}};
      points = 0;
      startTime = 0;
      start = System.currentTimeMillis();
      timer = start - timer;
   
   }
   
   
   public void detectWinner()
   {   
      if (points == 155 && timer <= 90) {
         Object[] options = {"Yes please", "No thank you"};
         int n = JOptionPane.showOptionDialog(null, "Congratulations, you have hit your target score of 155. Do you wanna play again?", "Option", JOptionPane.YES_NO_OPTION, 
            JOptionPane.QUESTION_MESSAGE, null, options, options[1]);
         
         if (n == 0)
            resetBoard();
         if (n ==1)
            System.exit(0); 
      }     
         
   }   
     
    
   public void detectLoser()    
   {
            
      if (timer > 90 && points < 155) {
         Object[] options = {"Yes please", "No thank you"};
         int n = JOptionPane.showOptionDialog(null, "You have lost get better. Would you like to play again?", "Option", JOptionPane.YES_NO_OPTION, 
            JOptionPane.QUESTION_MESSAGE, null, options, options[1]);
         
         if (n == 0)
            resetBoard();
         if (n ==1)
            System.exit(0);  
      }          
      
   }
}
